<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/dhavalsinhdhanajipatil/Documents/Ecommerce App With Laravel/HouseMaid/HouseMaid/vendor/filament/forms/resources/views/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>